package Gapp::Object;
use Moose;

extends 'Moose::Object';



1;