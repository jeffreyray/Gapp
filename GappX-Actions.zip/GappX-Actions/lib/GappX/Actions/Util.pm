package GappX::Actions::Util;

use Carp ();
use List::MoreUtils qw( all any );
use Scalar::Util qw( blessed reftype );
use Moose::Exporter;
use Scalar::Util 'blessed';

use GappX::Meta::Action;

Moose::Exporter->setup_import_methods(
    with_caller => [
        qw( action ),
    ],
);

sub action {
    my $caller = shift;
    my $name = shift;
    my %p = ref $_[0] eq 'HASH' ? %{$_[0]} : @_;
    
    my $action = GappX::Meta::Action->new( name => $name, %p );   
    $caller->REGISTRY->add_action( $action );
    return 1;
}



1;
