=head1 NAME

GappX::Actions::CheckedUtilExports - Wrap L<Moose::Util::TypeConstraints> to be
safer for L<GappX::Actions>

=cut

package GappX::Actions::CheckedUtilExports;
our $VERSION = "0.25";

use strict;
use warnings;
use Moose::Util::TypeConstraints ();
use Moose::Exporter;
use Sub::Name;
use Carp;

use namespace::clean -except => 'meta';

my $StringFoundMsg =
q{WARNING: String found where Type expected (did you use a => instead of a , ?)};

my @exports = qw/action subaction maybe_action duck_action enum coerce from as/;

=head1 DESCRIPTION

Prevents errors like:

    subaction Foo =>
    ...

Which should be written as:

    subaction Foo,
    ...

When using L<GappX::Actions>. Exported by that module.

Exports checked versions of the following subs:

C<action> C<subaction> C<maybe_action> C<duck_action> C<enum> C<coerce> C<from> C<as>

While C<class_action> and C<role_action> will also register the action in the library.

From L<Moose::Util::TypeConstraints>. See that module for syntax.

=cut

for my $export (@exports) {
    no strict 'refs';

    *{$export} = sub {
        my $caller = shift;

        local $Carp::CarpLevel = $Carp::CarpLevel + 1;

        carp $StringFoundMsg
            unless ref($_[0]) ||
                $_[0] =~ /\b::\b/ || # qualified action
                $caller->get_registered_class_action($_[0]) ||
                $caller->get_registered_role_action($_[0]);

        goto &{"Moose::Util::TypeConstraints::$export"};
    }
}

Moose::Exporter->setup_import_methods(
    with_caller => [ @exports, 'class_action', 'role_action' ]
);

sub class_action {
    my $caller = shift;

    $caller->register_class_action(
        Moose::Util::TypeConstraints::class_action(@_)
    );
}

sub role_action ($;$) {
    my ($caller, $name, $opts) = @_;

    $caller->register_role_action(
        Moose::Util::TypeConstraints::role_action($name, $opts)
    );
}

=head1 SEE ALSO

L<GappX::Actions>

=head1 AUTHOR

See L<GappX::Actions/AUTHOR>.

=head1 LICENSE

This program is free software; you can redistribute it and/or modify
it under the same terms as perl itself.

=cut

1;
