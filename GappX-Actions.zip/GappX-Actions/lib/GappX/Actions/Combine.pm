=head1 NAME

GappX::Actions::Combine - Combine action libraries for exporting

=cut

package GappX::Actions::Combine;
our $VERSION = "0.25";

use strict;
use warnings;
use Class::MOP ();

=head1 SYNOPSIS

    package CombinedTypeLib;

    use base 'GappX::Actions::Combine';

    __PACKAGE__->provide_actions_from(qw/TypeLib1 TypeLib2/);

    package UserClass;

    use CombinedTypeLib qw/Type1 Type2 ... /;

=head1 DESCRIPTION

Allows you to export actions from multiple action libraries. 

Libraries on the right side of the action libs passed to L</provide_actions_from>
take precedence over those on the left in case of conflicts.

=cut

sub import {
    my ($class, @actions) = @_;
    my $caller = caller;

    my %actions = $class->_provided_actions;

    my %from;
    for my $action (@actions) {
        unless ($actions{$action}) {
            my @action_libs = $class->provide_actions_from;

            die
                "$caller asked for a action ($action) which is not found in any of the"
                . " action libraries (@action_libs) combined by $class\n";
        }

        push @{ $from{ $actions{$action} } }, $action;
    }

    $_->import({ -into => $caller }, @{ $from{ $_ } })
        for keys %from;
}

=head1 CLASS METHODS

=head2 provide_actions_from

Sets or returns a list of action libraries to re-export from.

=cut

sub provide_actions_from {
    my ($class, @libs) = @_;

    my $store =
     do { no strict 'refs'; \@{ "${class}::__MOOSEX_TYPELIBRARY_LIBRARIES" } };

    if (@libs) {
        $class->_check_action_lib($_) for @libs;
        @$store = @libs;

        my %actions = map {
            my $lib = $_;
            map +( $_ => $lib ), $lib->action_names
        } @libs;

        $class->_provided_actions(%actions);
    }

    @$store;
}

sub _check_action_lib {
    my ($class, $lib) = @_;

    Class::MOP::load_class($lib);

    die "Cannot use $lib in a combined action library, it does not provide any actions"
        unless $lib->can('action_names');
}

sub _provided_actions {
    my ($class, %actions) = @_;

    my $actions =
     do { no strict 'refs'; \%{ "${class}::__MOOSEX_TYPELIBRARY_TYPES" } };

    %$actions = %actions
        if keys %actions;

    %$actions;
}

=head1 SEE ALSO

L<GappX::Actions>

=head1 AUTHOR

See L<GappX::Actions/AUTHOR>.

=head1 LICENSE

This program is free software; you can redistribute it and/or modify
it under the same terms as perl itself.

=cut

1;
