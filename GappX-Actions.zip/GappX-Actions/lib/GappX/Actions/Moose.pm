package GappX::Actions::Moose;
our $VERSION = "0.25";

=head1 NAME

GappX::Actions::Moose - Types shipped with L<Moose>

=cut

use warnings;
use strict;

use GappX::Actions;
use Moose::Util::TypeConstraints ();

use namespace::clean -except => [qw( meta )];

=head1 SYNOPSIS

  package Foo;
  use Moose;
  use GappX::Actions::Moose qw( Int Str );
  use Carp qw( croak );

  has 'name',
    is  => 'rw',
    isa => Str;

  has 'id',
    is  => 'rw',
    isa => Int;

  sub add {
      my ($self, $x, $y) = @_;
      croak 'First arg not an Int'  unless is_Int($x);
      croak 'Second arg not an Int' unless is_Int($y);
      return $x + $y;
  }

  1;

=head1 DESCRIPTION

This package contains a virtual library for L<GappX::Actions> that
is able to export all actions known to L<Moose>. See L<GappX::Actions>
for general usage information.

=cut

# all available builtin actions as short and long name
my %BuiltIn_Storage 
  = map { ($_) x 2 } 
    Moose::Util::TypeConstraints->list_all_builtin_action_constraints;

=head1 METHODS

=head2 action_storage

Overrides L<GappX::Actions::Base>' C<action_storage> to provide a hash
reference containing all built-in L<Moose> actions.

=cut

# use prepopulated builtin hash as action storage
sub action_storage { \%BuiltIn_Storage }

=head1 SEE ALSO

L<GappX::Actions::Moose>,
L<Moose>, 
L<Moose::Util::TypeConstraints>

=head1 AUTHOR

See L<GappX::Actions/AUTHOR>.

=head1 LICENSE

This program is free software; you can redistribute it and/or modify
it under the same terms as perl itself.

=cut

1;
