package GappX::Actions::Base;
our $VERSION = "0.25";
use Moose;

use Carp::Clan                      qw( ^GappX::Actions );
use GappX::Actions::Util;
use GappX::Meta::Action::Registry;
use Sub::Exporter                   qw( build_exporter );
use Moose::Util::TypeConstraints;

use namespace::clean -except => [qw( meta )];

my $UndefMsg = q{Unable to find action '%s' in library '%s'};

sub import {
    my ($class, @args) = @_;

    # filter or create options hash for S:E
    my $options = (@args and (ref($args[0]) eq 'HASH')) ? $args[0] : undef;
    unless ($options) {
        $options = {foo => 23};
        unshift @args, $options;
    }

    # all actions known to us
    my @actions = $class->action_names;
    print "\t>", @actions, "\n";

    # determine the wrapper, -into is supported for compatibility reasons
    my $wrapper = $options->{ -wrapper } || 'GappX::Actions';
    $args[0]->{into} = $options->{ -into } 
        if exists $options->{ -into };

    my (%ex_spec, %ex_util);
    
    # create the functions for export
    for my $action_short (@actions) {
        # the action itself
        push @{ $ex_spec{exports} }, 
            $action_short,
            sub { 
                bless $wrapper->action_export_generator($class, $action_short),
                    'GappX::Actions::EXPORTED_ACTION';
            };
            
        push @{ $ex_spec{exports} }, 
            'do_' . $action_short,
            sub { 
                $wrapper->perform_export_generator($class, $action_short)
            };
    }

    # create S:E exporter and increase export level unless specified explicitly
    my $exporter = build_exporter \%ex_spec;
    $options->{into_level}++ 
        unless $options->{into};
        

    # and on to the real exporter
    my @new_args = (@args, map { 'do_' . $_ } @actions); #, keys %add);
    return $class->$exporter(@new_args);
}

=head2 get_action

This returns a action from the library's store by its name.

=cut

sub get_action {
    my ($class, $action) = @_;
    
    

    # useful message if the action couldn't be found
    croak "Unknown action '$action' in library '$class'"
        unless $class->has_action($action);

    # return real name of the action
    return $class->action_storage->{ $action };
}

=head2 action_names

Returns a list of all known actions by their name.

=cut

sub action_names {
    my ($class) = @_;

    print $class, "\n";
    print "\t-", $class->REGISTRY->action_list, "\n";
    print "\t-", keys %{ $class->action_storage }, "\n";
    
    # $class->REGISTRY->action_list
    # return short names of all stored actions
    return keys %{ $class->action_storage };
}

=head2 add_action

Adds a new action to the library.

=cut

sub add_action {
    my ($class, $action) = @_;
    
    # store action with library prefix as real name
    $class->action_storage->{ $action } = "${class}::${action}";
}

=head2 has_action

Returns true or false depending on if this library knows a action by that
name.

=cut

sub has_action {
    my ($class, $action) = @_;

    # check if we stored a action under that name
    return ! ! $class->action_storage->{ $action };
}

=head2 action_storage

Returns the library's action storage hash reference. You shouldn't use this
method directly unless you know what you are doing. It is not an internal
method because overriding it makes virtual libraries very easy.

=cut

sub action_storage {
    my ($class) = @_;

    # return a reference to the storage in ourself
    {   no strict 'refs';
        return \%{ $class . '::__GAPPX_ACTION_STORAGE' };
    }
}



{
    my %REGISTRY;

    sub REGISTRY {
        my $caller = shift;
        return $REGISTRY{$caller} ||= GappX::Meta::Action::Registry->new;
    }
}

1;
