package GappX::Actions::Foo;
use GappX::Actions -declare => [qw( New Edit Delete )];
use MooseX::Types::Moose qw( CodeRef );

action 'New' => {
    label => 'New',
    icon => 'gtk-new',
    code => sub {
        print 'new action', "\n";
        return 'new';
    }
};

action 'Edit' => {
    label => 'New',
    icon => 'gtk-new',
    code => sub {
        print 'edit action', "\n";
        return 'edit';
    }
};

action 'Delete' => {
    label => 'New',
    icon => 'gtk-new',
    code => sub {
        print 'new action', "\n";
        return 'delete';
    }
};
1;
