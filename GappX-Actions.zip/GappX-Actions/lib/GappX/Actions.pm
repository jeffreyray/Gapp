package GappX::Actions;
use Moose;

=head1 NAME

GappX::Actions - Organise your Moose actions in libraries

=cut

use Moose::Util::TypeConstraints;
use GappX::Actions::TypeDecorator;
use GappX::Actions::UndefinedType;
use GappX::Actions::Base;
use GappX::Actions::Util;
use GappX::Actions::CheckedUtilExports ();
use Carp::Clan                        qw( ^GappX::Actions );
use Sub::Name;
use Scalar::Util                      'reftype';

use namespace::clean -except => [qw( meta )];

use 5.008;
our $VERSION = '0.25';
my $UndefMsg = q{Action for action '%s' not yet defined in library '%s'};


sub import {
    my ($class, %args) = @_;
    my  $callee = caller;

    # everyone should want this
    strict->import;
    warnings->import;

    # inject base class into new library
    {   no strict 'refs';
        unshift @{ $callee . '::ISA' }, 'GappX::Actions::Base';
    }

    # generate predeclared action helpers
    if (my @orig_declare = @{ $args{ -declare } || [] }) {
        my @to_export;

        for my $action (@orig_declare) {

            croak "Cannot create an action containing '::' ($action) at the moment"
                if $action =~ /::/;

            # add action to library and remember to export
            $callee->add_action( $action );
            push @to_export, $action;
        }

        $callee->import({ -full => 1, -into => $callee }, @to_export);
    }

    GappX::Actions::Util->import({ into => $callee });

    1;
}

=head2 action_export_generator

Generate an action export function, e.g. C<OpenFile()>. This will return a
a GappX::Meta::Action object.

=cut

sub action_export_generator {
    my ($class, $caller, $action) = @_;
    
    ## Return an anonymous subroutine that will generate the proxied action
    ## constraint for you.
    return subname "__ACTION__::" . $caller . "::" . "$action" => sub {
        return $caller->REGISTRY->action( $action );
    };
}

sub perform_export_generator {
    my ($class, $caller, $action) = @_;
    
    ## Return an anonymous subroutine that will generate the proxied action
    ## constraint for you.
    return sub {
        return $caller->REGISTRY->action( $action )->code->( @_ );
    };
}
1;
