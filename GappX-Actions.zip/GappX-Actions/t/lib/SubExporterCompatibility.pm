package SubExporterCompatibility; {
    
    use GappX::Actions::Moose qw(Str);
    use GappX::Actions -declare => [qw(MyStr)];
    use Sub::Exporter -setup => { exports => [ qw(something MyStr) ] };
    
    subaction MyStr,
     as Str;
     
    sub something {
        return 1;
    }    
    
} 1;
