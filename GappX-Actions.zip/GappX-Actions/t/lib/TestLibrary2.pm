package TestLibrary2;

use GappX::Actions
    -declare => [qw( MTFNPY NonEmptyStr )];
use GappX::Actions::Moose 'Str';

subaction MTFNPY,
    as Str,
    where { length $_ },
    message { 'MTFNPY must not be empty' };

subaction NonEmptyStr,
    as Str,
    where { length $_ },
    message { 'Str must not be empty' };

1;
