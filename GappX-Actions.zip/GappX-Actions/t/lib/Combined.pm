package Combined;

use strict;
use warnings;

use base 'GappX::Actions::Combine';

__PACKAGE__->provide_actions_from(qw/TestLibrary TestLibrary2/);

1;
