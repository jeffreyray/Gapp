package TestLibrary;
use warnings;
use strict;

use GappX::Actions::Moose qw( Str ArrayRef Int );
use GappX::Actions
    -declare => [qw( NonEmptyStr IntArrayRef TwentyThree Foo2Alias )];

subaction NonEmptyStr,
    as Str,
    where { length $_ },
    message { 'Str must not be empty' };

coerce NonEmptyStr,
    from Int,
        via { "$_" };

subaction IntArrayRef,
    as ArrayRef,
    where { not grep { $_ !~ /^\d+$/ } @$_ },
    message { 'ArrayRef contains non-Int value' };

coerce IntArrayRef,
    from Int,
        via { [$_] };

subaction TwentyThree,
    as Int,
    where { $_ == 23 },
    message { 'Int is not 23' };

subaction Foo2Alias,
    as Str,
    where { 1 };

1;
