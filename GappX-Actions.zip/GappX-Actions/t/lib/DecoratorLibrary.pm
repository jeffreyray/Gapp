package DecoratorLibrary;

use GappX::Actions::Moose qw( Str ArrayRef HashRef Int Object);
use GappX::Actions
    -declare => [qw(
        MyArrayRefBase
        MyArrayRefInt01
        MyArrayRefInt02
        MyHashRefOfInts
        MyHashRefOfStr
        StrOrArrayRef
        AtLeastOneInt
        Jobs
        SubOfMyArrayRefInt01
        BiggerInt
        isFive
        isTen
        isFifteen
        TwoEqualArrayRefs
        VeryBigInt
        FiveOrTenOrFifteen
        WierdIntergersArrayRef1
        WierdIntergersArrayRef2
    )];

subaction MyArrayRefBase,
    as ArrayRef;
    
coerce MyArrayRefBase,
    from Str,
    via {[split(',', $_)]};
    
subaction MyArrayRefInt01,
    as ArrayRef[Int];

subaction BiggerInt,
    as Int,
    where {$_>10};
    
subaction SubOfMyArrayRefInt01,
    as MyArrayRefInt01[BiggerInt];

coerce MyArrayRefInt01,
    from Str,
    via {[split('\.',$_)]},
    from HashRef,
    via {[sort values(%$_)]};
    
subaction MyArrayRefInt02,
    as MyArrayRefBase[Int];
    
subaction MyHashRefOfInts,
    as HashRef[Int];
    
subaction MyHashRefOfStr,
    as HashRef[Str];

coerce MyArrayRefInt02,
    from Str,
    via {[split(':',$_)]},
    from MyHashRefOfInts,
    via {[sort values(%$_)]},
    from MyHashRefOfStr,
    via {[ sort map { length $_ } values(%$_) ]},
    from HashRef[ArrayRef],
    via {[ sort map { @$_ } values(%$_) ]};

subaction StrOrArrayRef,
    as Str|ArrayRef;

subaction AtLeastOneInt,
    as ArrayRef[Int],
    where { @$_ > 0 };
    
enum Jobs,
    (qw/Programming Teaching Banking/);
    
subaction isFive,
 as Int,
 where { $_ == 5};

subaction isTen,
 as Int,
 where { $_ == 10};
 
subaction isFifteen,
 as Int,
 where { $_ == 15};
 
subaction VeryBigInt,
 as BiggerInt,
 where {$_>100};
 
subaction FiveOrTenOrFifteen,
 as isFive|isTen|isFifteen;

subaction WierdIntergersArrayRef1,
 as ArrayRef[FiveOrTenOrFifteen|VeryBigInt];

subaction WierdIntergersArrayRef2,
 as ArrayRef[FiveOrTenOrFifteen|Object];    
1;
