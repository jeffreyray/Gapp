package IntrospectTypeExports;
use strict;
use warnings;

use GappX::Actions::Util qw( has_available_action_export );

my @Memory;

sub import {
    my ($class, $package, @actions) = @_;

    for my $action (@actions) {
        my $tc     = has_available_action_export($package, $action);
        push @Memory, [$package, $action, $tc ? $tc->name : undef];
    }
}

sub get_memory { \@Memory }

1;
