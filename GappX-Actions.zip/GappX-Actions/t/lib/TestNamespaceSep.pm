package TestNamespaceSep;
use warnings;
use strict;

use GappX::Actions -declare => [qw( Foo::Bar )];

1;
